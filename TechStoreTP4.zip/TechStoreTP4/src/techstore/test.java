package techstore;

public class test {
	public void main() {
		Adresse a1= new Adresse("Monastir",5000);
		Adresse a2= new Adresse("Ben Arous",4096);
		Personne p1= new Personne("15226890","bechir","ben said",a1);
		Personne p2= new  Personne("15223698","moez","toumi",a2);
		System.out.println(a1);
	}
}
