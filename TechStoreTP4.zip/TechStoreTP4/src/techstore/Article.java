package techstore;

public class Article {
	private int id;
	private String nom;
	private String reference;
	private double prix;
	public Article(int id,String nom,String reference,double prix) {
		this.id=id;
		this.nom=nom;
		this.reference=reference;
		this.prix=prix;
	}
	public int getid() {
		return id;
	}
	public String getnom() {
		return nom;
	}
	public String getreference() {
		return reference;
	}
	public double getprix() {
		return prix;
	}
	public void setid(int id) {
		this.id=id;
	}
	public void setnom(String nom) {
		this.nom=nom;
	}
	public void setreference(String reference) {
		this.reference=reference;
	}
	public void setprix(double prix) {
		this.prix=prix;
	}
	public String toString() {
		return"Article[id="+ id +",nom="+ nom +",reference="+ reference +",prix="+ prix +"]";
	}
}
