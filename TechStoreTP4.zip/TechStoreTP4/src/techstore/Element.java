package techstore;

public class Element {
	private Article article;
	private long quantite;
	public Element(Article article,long quantite) {
		this.article=article;
		this.quantite=quantite;
	}
	public Article getarticle() {
		return article;
	}
	public long getquantite() {
		return quantite;
	}
	public void setarticle(Article article) {
		this.article=article;
	}
	public void setquantite(long quantite) {
		this.quantite=quantite;
	}
	public String toString() {
		return "Element [article="+article+",quantite="+quantite+"]";
	}
}