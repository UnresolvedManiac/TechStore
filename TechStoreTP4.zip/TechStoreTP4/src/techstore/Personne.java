package techstore;

public class Personne {
	private String cin;
	private String nom;
	private String prenom;
	private Adresse adresse;
	public Personne (String cin,String nom,String prenom,Adresse adresse) {
		this.cin=cin;
		this.nom=nom;
		this.prenom=prenom;
		this.adresse=adresse;
	}
	public String getcin() {
		return cin;
	}
	public String getnom() {
		return nom;
	}
	public String getprenom() {
		return prenom;
	}
	public void setcin(String cin) {
		this.cin=cin;
	}
	public void setnom(String nom) {
		this.nom=nom;
	}
	public void setprenom(String prenom) {
		this.prenom=prenom;
	}
	public void setadresse(Adresse adresse) {
		this.adresse=adresse;
	}
	public String toString() {
		return "Personne [cin=" + cin + ", nom=" + nom + ",prenom="+ prenom +",adresse="+ adresse +"]";
	}
}
