package techstore;
import java.util.ArrayList;

public class Stock {
    private ArrayList<Element> articleList;

    public Stock() {
        this.articleList = new ArrayList<>();
    }

    public Stock(ArrayList<Element> articleList) {
        this.articleList = articleList != null ? articleList : new ArrayList<>();
    }

    public Stock(Article article, ArrayList<Long> quantites) {
    	 ArrayList<String> noms;
         ArrayList<Double> prix;
        this.articleList = new ArrayList<>();
       
        if (noms != null && prix != null && quantites != null) {
            int taille = Math.min(noms.size(), Math.min(prix.size(), quantites.size()));
            for (int i = 0; i < taille; i++) {
                articleList.add(new Element(article, quantites.get(i)));
            }
        }
    }

    public ArrayList<Element> getArticleList() {
        return articleList;
    }

    public int getArticleNb() {
        return articleList.size();
    }

    public void setArticleList(ArrayList<Element> articleList) {
        this.articleList = articleList;
    }

    public void ajouterArticle(Article article, long quantite) {
        if (article != null) {
            articleList.add(new Element(article, quantite));
        }
    }

    public void ajouterArticle(String nom, double prix, long quantite) {
        articleList.add(new Element(nom, prix, quantite));
    }

    public Element trouverArticle(String reference) {
        for (Element e : articleList) {
            if (e.equals(reference)) {
                return e;
            }
        }
        return null;
    }

    public void modifierArticle(String reference, String nouveauNom, double nouveauPrix, long nouvelleQuantite) {
        Element e = trouverArticle(reference);
        if (e != null) {
            e.modifier(nouveauNom, nouveauPrix, nouvelleQuantite);
        }
    }

    public void supprimerArticle(String reference) {
        Element e = trouverArticle(reference);
        if (e != null) {
            articleList.remove(e);
        }
    }

    public void incrementerQuantiteArticle(String reference, long quantite) {
        Element e = trouverArticle(reference);
        if (e != null) {
            e.incrementerQuantite(quantite);
        }
    }

    public void decrementerQuantiteArticle(String reference, long quantite) {
        Element e = trouverArticle(reference);
        if (e != null) {
            e.decrementerQuantite(quantite);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Element e : articleList) {
            sb.append(e.toString()).append("\n");
        }
        return sb.toString();
    }
}
